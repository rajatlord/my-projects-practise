import { Routes, Route, Link , NavLink} from "react-router-dom";
import Home from "./pages/Home";
import About from "./pages/About";
import Dashboard from "./pages/Dashboard";
import Profile from "./pages/Profile";
import Settings from "./pages/Settings";
import Products from "./pages/Products";
import ProductDetails from "./pages/ProductDetails";
import NotFound from "./pages/NotFound";
import Navbar from "./pages/Navbar";

// importing work as about
// import Work from "./work"


function App() {
  return (
    <div>
      <Navbar/>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        {/* <Route path="/about" element={<Work />} /> */}
        <Route path="/products" element={<Products />} >
        <Route path=":id" element={<ProductDetails/>}/>
      </Route>
      <Route path="*" element={<NotFound/>} />

        <Route path="/dashboard" element={<Dashboard />}>
          <Route path="profile" element={<Profile />} />
          <Route path="settings" element={<Settings />} />
        </Route>
        <Route path="*" element={<h2>page not found</h2>} />
      </Routes>
      
    </div>
  );
}

export default App;

// import { BrowserRouter as Router , Routes, Route, Link } from "react-router-dom";
// import Home from "./pages/Home";
// import About from "./pages/About";
// import './App.css'

// import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
// import Dashboard from "./pages/Dashboard";
// import Profile from "./pages/Profile";
// import Settings from "./pages/Settings";

// function App() {
//   return (
//     <>
//     <h1>HI</h1>
//     <nav>
//           <Link to="/">Home</Link>|<Link to="/about">About</Link>
//         </nav>
//     <Router>
//       <Routes>
//       <Route path="/" element={<Home />} />
//       <Route path="/about" element={<About />} />
//         <Route path="/dashboard" element={<Dashboard />}>
//           <Route path="profile" element={<Profile />} />
//           <Route path="settings" element={<Settings />} />
//         </Route>
//       </Routes>
//     </Router>
//     </>
//   );
// }

// export default App;

// simply route
{
  /* <nav>
          <Link to="/">Home</Link>|<Link to="/about">About</Link>
        </nav>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
        </Routes> */
}
