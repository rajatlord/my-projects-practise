import NameComponents from "./Hooks/useMemo/NameComponents";
import ResultComponents from "./Hooks/useMemo/ResultComponents";
import "./App.css";
import Parent from "./Hooks/useCallback/Parent";




function App() {
  

  return <>
    {/* <NameComponents name="ROMA"/> */}
    {/* <ResultComponents marks={70} subject="Science"/> */}
    <Parent />
  </>;
}

export default App;
